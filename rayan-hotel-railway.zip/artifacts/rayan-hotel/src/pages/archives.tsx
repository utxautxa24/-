import { useState, useRef } from "react";
import { Link } from "wouter";
import { useListFolders, useCreateFolder, useListFiles, useDeleteFile, getListFoldersQueryKey, getListFilesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/i18n";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { FolderOpen, Plus, Upload, Download, Trash2, Search, File } from "lucide-react";
import { formatBytes, formatDate, getFileIconEmoji } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function ArchivesPage() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: folders = [], isLoading: foldersLoading } = useListFolders({});
  const { data: files = [], isLoading: filesLoading } = useListFiles({ folderId: undefined, search });
  const createFolder = useCreateFolder();
  const deleteFile = useDeleteFile();

  const canUpload = user?.role === "super_admin" || user?.role === "manager";
  const canDelete = user?.role === "super_admin" || user?.role === "manager";

  const rootFolders = folders.filter((f: any) => !f.parentId);

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    await createFolder.mutateAsync({ data: { name: newFolderName.trim() } });
    queryClient.invalidateQueries({ queryKey: getListFoldersQueryKey() });
    setNewFolderName("");
    setShowCreateFolder(false);
    toast({ title: "Folder created" });
  };

  const uploadFiles = async (fileList: FileList | null) => {
    if (!fileList) return;
    setUploading(true);
    const token = localStorage.getItem("rayan_token");
    for (const file of Array.from(fileList)) {
      const fd = new FormData();
      fd.append("file", file);
      await fetch("/api/files", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: fd,
      });
    }
    queryClient.invalidateQueries({ queryKey: getListFilesQueryKey() });
    setUploading(false);
    toast({ title: `${fileList.length} file(s) uploaded` });
  };

  const handleDeleteFile = async (id: number, name: string) => {
    if (!confirm(t("common.confirm"))) return;
    await deleteFile.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getListFilesQueryKey() });
    toast({ title: `${name} deleted` });
  };

  const rootFiles = files.filter((f: any) => !f.folderId);

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-primary" />
            {t("nav.archives")}
          </h1>
          <div className="flex items-center gap-2">
            {canUpload && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowCreateFolder(true)}
                  data-testid="btn-create-folder"
                >
                  <Plus className="w-3.5 h-3.5 mr-1.5" />
                  {t("folders.create")}
                </Button>
                <Button
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  data-testid="btn-upload"
                >
                  <Upload className="w-3.5 h-3.5 mr-1.5" />
                  {uploading ? t("common.loading") : t("files.upload")}
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => uploadFiles(e.target.files)}
                  data-testid="input-file-upload"
                />
              </>
            )}
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={t("common.search")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-files"
          />
        </div>

        {/* Drag & Drop Zone */}
        {canUpload && (
          <div
            className={cn(
              "border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer",
              isDragging
                ? "border-primary bg-primary/10"
                : "border-border hover:border-primary/50 hover:bg-accent/50"
            )}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragging(false); uploadFiles(e.dataTransfer.files); }}
            onClick={() => fileInputRef.current?.click()}
            data-testid="dropzone"
          >
            <Upload className={cn("w-8 h-8 mx-auto mb-2", isDragging ? "text-primary" : "text-muted-foreground")} />
            <p className="text-sm text-muted-foreground">{t("files.dragDrop")}</p>
            {uploading && <p className="text-xs text-primary mt-1 animate-pulse">{t("common.loading")}</p>}
          </div>
        )}

        {/* Folders grid */}
        {foldersLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
          </div>
        ) : rootFolders.length > 0 ? (
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground mb-3">Folders</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {rootFolders.map((folder: any) => (
                <Link key={folder.id} href={`/folders/${folder.id}`}>
                  <div
                    className="flex flex-col items-center gap-2 p-4 bg-card border border-border rounded-xl hover:border-primary/40 hover:bg-accent/50 transition-all cursor-pointer group"
                    data-testid={`folder-${folder.id}`}
                  >
                    <FolderOpen className="w-8 h-8 text-amber-400 group-hover:text-primary transition-colors" />
                    <p className="text-xs font-medium text-foreground text-center truncate w-full">{folder.name}</p>
                    {folder.fileCount !== undefined && (
                      <p className="text-[10px] text-muted-foreground">{folder.fileCount} files</p>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ) : null}

        {/* Root files */}
        {!search && rootFiles.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground mb-3">Root Files</h2>
            <Card className="bg-card border-border overflow-hidden">
              <div className="divide-y divide-border">
                {rootFiles.map((file: any) => (
                  <div key={file.id} className="flex items-center gap-3 px-4 py-3 hover:bg-accent/50 transition-colors" data-testid={`file-${file.id}`}>
                    <span className="text-xl flex-shrink-0">{getFileIconEmoji(file.mimeType)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
                      <p className="text-xs text-muted-foreground">{file.uploaderName} · {formatDate(file.createdAt)} · {formatBytes(file.size)}</p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <a href={`/api/files/${file.id}/download`} target="_blank" rel="noreferrer"
                        className="p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                        data-testid={`btn-download-${file.id}`}>
                        <Download className="w-4 h-4" />
                      </a>
                      {canDelete && (
                        <button onClick={() => handleDeleteFile(file.id, file.name)}
                          className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                          data-testid={`btn-delete-${file.id}`}>
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* Search results */}
        {search && (
          <Card className="bg-card border-border overflow-hidden">
            <CardHeader className="pb-2 border-b border-border">
              <CardTitle className="text-sm">{files.length} {t("common.search")} results</CardTitle>
            </CardHeader>
            <div className="divide-y divide-border">
              {files.map((file: any) => (
                <div key={file.id} className="flex items-center gap-3 px-4 py-3 hover:bg-accent/50 transition-colors" data-testid={`search-file-${file.id}`}>
                  <span className="text-xl flex-shrink-0">{getFileIconEmoji(file.mimeType)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{file.uploaderName} · {formatBytes(file.size)}</p>
                  </div>
                  <a href={`/api/files/${file.id}/download`} target="_blank" rel="noreferrer"
                    className="p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              ))}
              {files.length === 0 && (
                <div className="p-6 text-center text-muted-foreground text-sm">{t("common.noData")}</div>
              )}
            </div>
          </Card>
        )}

        {/* Create folder dialog */}
        <Dialog open={showCreateFolder} onOpenChange={setShowCreateFolder}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>{t("folders.create")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <Input
                placeholder={t("folders.name")}
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleCreateFolder()}
                data-testid="input-folder-name"
                autoFocus
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateFolder(false)}>{t("common.cancel")}</Button>
              <Button onClick={handleCreateFolder} disabled={createFolder.isPending} data-testid="btn-create-folder-confirm">
                {t("common.create")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
