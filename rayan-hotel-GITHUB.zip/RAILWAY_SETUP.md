# Деплой на Railway через GitHub

## Шаг 1 — Отправьте код на GitHub

### Из Replit:
1. Откройте вкладку **Version Control** (иконка ветки слева в Replit)
2. Нажмите **Connect to GitHub**
3. Авторизуйтесь в GitHub
4. Нажмите **Create a GitHub repository**
5. Дайте имя: `rayan-hotel`
6. Нажмите **Push** — код загрузится на GitHub

---

## Шаг 2 — Создайте проект на Railway

1. Зайдите на [railway.app](https://railway.app)
2. **New Project** → **Deploy from GitHub repo**
3. Выберите ваш репозиторий `rayan-hotel`
4. Railway автоматически обнаружит `railway.json`

---

## Шаг 3 — Добавьте PostgreSQL

1. В проекте Railway нажмите **+ New**
2. Выберите **Database** → **Add PostgreSQL**
3. Railway автоматически добавит `DATABASE_URL` в переменные

---

## Шаг 4 — Настройте переменные окружения

В Railway → вашем сервисе → вкладка **Variables** добавьте:

| Переменная | Значение |
|---|---|
| `JWT_SECRET` | любая длинная строка, например: `rayan_hotel_secret_2025_xkq9z` |
| `NODE_ENV` | `production` |
| `REPLIT_OBJECT_STORAGE_BUCKET_ID` | `replit-objstore-13e09cac-c4d6-45e2-9180-082eb2bc4672` |

> `DATABASE_URL` и `PORT` Railway добавит сам автоматически.

---

## Шаг 5 — Миграция базы данных

После первого деплоя откройте **Railway Shell** (или используйте Railway CLI):

```bash
# Создать таблицы
pnpm --filter @workspace/db run push

# Заполнить начальными данными (admin + папки)
pnpm --filter @workspace/db run seed
```

---

## Готово!

Сайт будет доступен по адресу: `https://ваш-проект.up.railway.app`

Логин администратора:
- **Email:** `omurbek@rayan.kg`
- **Пароль:** `admin`

---

## Структура (один сервис)

```
GitHub репозиторий
    ↓
Railway сервис
    ↓
Express сервер (PORT из Railway)
    ├── /api/*     → бэкенд роуты
    └── /*         → React фронтенд (static)
```
